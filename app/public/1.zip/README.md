# eggApi


- 本项目打算在egg.js 基础模板上添加常用的项目中的功能， 比如
  + 单点登录 sso
  + 跨域资源共享 cros
  + 文件上传，断点续传
  + 文件下载
  + api请求转发
  + excel 文件插入到数据库， 将数据库数据导出到excel
  + n级联动数据格式读取
  + 


## QuickStart

<!-- add docs here for user -->

see [egg docs][egg] for more detail.

### Development

```bash
$ npm i
$ npm run dev
$ open http://localhost:7001/
```

### Deploy

```bash
$ npm start
$ npm stop
```

### npm scripts

- Use `npm run lint` to check code style.
- Use `npm test` to run unit test.
- Use `npm run autod` to auto detect dependencies upgrade, see [autod](https://www.npmjs.com/package/autod) for more detail.


[egg]: https://eggjs.org